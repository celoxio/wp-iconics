  window.addEventListener("DOMContentLoaded", function() {
      console.log('woohooooo!!!');
      document.getElementById('overlay').remove();
  });
